#!/bin/bash
cd /home/ec2-user
echo "stop test" >> ./endloadtest.txt
sleep 10
exit 0