

var htmlReportTemplate = 
"<html>" + 
"<head>" + 
"  <script src='https://code.highcharts.com/highcharts.js'>" + 
"  </script><script src='https://code.highcharts.com/modules/exporting.js'></script>" + 
"</head>" + 
"<body>CHARTPLACEHOLDER" + 
"</body></html> ";

var htmlChartTemplate = 
"<div id='DIVID'></div><script type='text/javascript'>Highcharts.chart('DIVID', { " +
"    title: {text: 'CHARTTITLE'}, " +
"    yAxis: {title: {text: 'Values'}}, " + 
"    legend: {layout: 'vertical',align: 'right',verticalAlign: 'middle'}, " +
"    series: SERIES_PLACEHOLDER" + 
"});" + 
"</script>"

var smallestTimestamp = 0;

/**
 * returns a string that contains a full HTML Page that renders each inddiviudal metric in a chart
 */
exports.buildHtmlChartReport = function(responseDataObject) {
    
    var allChartsHtml = "";
    
    for(var metricIx=0;metricIx<responseDataObject.length;metricIx++) {
        var metricObject = responseDataObject[metricIx];
        
        var metricObjectName = Object.keys(metricObject)[0];
        var metricObjectValues = metricObject[metricObjectName];
        
        var stringifiedSeries = JSON.stringify(metricObjectValues).replace(/["]/g, "'");
        console.log("REPLACE: " + stringifiedSeries);
        var chartHtml = htmlChartTemplate.replace(/DIVID/g, "Chart_" + metricIx.toString()).replace("CHARTTITLE", metricObjectName).replace("SERIES_PLACEHOLDER", stringifiedSeries);
        allChartsHtml = allChartsHtml + chartHtml;
    }
    
    return htmlReportTemplate.replace("CHARTPLACEHOLDER", allChartsHtml);
}